# Formulario de Contacto

Proyecto desarrollado con React, Vite y Tailwind CSS para la actividad de Programación Web 1.

## Requisitos funcionales
- Maneja nombre, email y mensaje con `useState`.
- Los campos son controlados mediante `value` y `onChange`.
- Valida nombre, formato de email y longitud del mensaje.
- Impide el envío si existen errores.
- Muestra una confirmación de éxito al completar correctamente el formulario.
- El envío es simulado, tal como indica la actividad.

## Cómo ejecutar el proyecto

1. Instala Node.js (versión LTS).
2. Descomprime el archivo ZIP.
3. Abre la carpeta `Formulario_de_Contacto_React` en Visual Studio Code.
4. Abre una terminal en esa carpeta y ejecuta:

```bash
npm install
npm run dev
```

5. Abre en el navegador la dirección local que Vite muestra en la terminal (normalmente `http://localhost:5173`).

## Subir a GitHub
Crea un repositorio público en GitHub y sube el contenido de esta carpeta. No subas la carpeta `node_modules`.
