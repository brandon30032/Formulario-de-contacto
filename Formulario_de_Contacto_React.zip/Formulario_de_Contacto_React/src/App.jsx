import { useState } from 'react'

const initialForm = {
  nombre: '',
  email: '',
  mensaje: '',
}

function App() {
  const [formulario, setFormulario] = useState(initialForm)
  const [errores, setErrores] = useState({})
  const [enviado, setEnviado] = useState(false)

  const manejarCambio = (evento) => {
    const { name, value } = evento.target
    setFormulario((previo) => ({ ...previo, [name]: value }))
    setEnviado(false)
    setErrores((previo) => ({ ...previo, [name]: '' }))
  }

  const validarFormulario = () => {
    const nuevosErrores = {}

    if (!formulario.nombre.trim()) {
      nuevosErrores.nombre = 'Por favor, escribe tu nombre.'
    } else if (formulario.nombre.trim().length < 2) {
      nuevosErrores.nombre = 'El nombre debe tener al menos 2 caracteres.'
    }

    const formatoEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!formulario.email.trim()) {
      nuevosErrores.email = 'Por favor, escribe tu correo electrónico.'
    } else if (!formatoEmail.test(formulario.email.trim())) {
      nuevosErrores.email = 'Ingresa un correo electrónico válido.'
    }

    if (!formulario.mensaje.trim()) {
      nuevosErrores.mensaje = 'Por favor, escribe tu mensaje.'
    } else if (formulario.mensaje.trim().length < 10) {
      nuevosErrores.mensaje = 'El mensaje debe tener al menos 10 caracteres.'
    }

    return nuevosErrores
  }

  const manejarEnvio = (evento) => {
    evento.preventDefault()
    const nuevosErrores = validarFormulario()
    setErrores(nuevosErrores)

    if (Object.keys(nuevosErrores).length === 0) {
      setEnviado(true)
      setFormulario(initialForm)
    } else {
      setEnviado(false)
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 px-4 py-10 sm:py-16">
      <div className="mx-auto max-w-5xl">
        <header className="mb-10 text-center">
          <span className="mb-4 inline-flex rounded-full border border-indigo-400/30 bg-indigo-400/10 px-4 py-2 text-sm font-semibold text-indigo-200">
            Estamos aquí para ayudarte
          </span>
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
            Formulario de <span className="text-indigo-400">Contacto</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-slate-300 sm:text-lg">
            ¿Tienes una idea o necesitas información? Envíanos un mensaje y nos pondremos en contacto contigo.
          </p>
        </header>

        <section className="mx-auto max-w-2xl rounded-3xl border border-white/10 bg-white/[0.06] p-6 shadow-2xl shadow-black/30 backdrop-blur sm:p-10">
          {enviado && (
            <div role="status" className="mb-6 rounded-xl border border-emerald-400/30 bg-emerald-400/10 p-4 text-emerald-200">
              <p className="font-semibold">¡Gracias por tu mensaje!</p>
              <p className="mt-1 text-sm">Tu formulario se ha enviado correctamente (envío simulado).</p>
            </div>
          )}

          <form onSubmit={manejarEnvio} noValidate className="space-y-6">
            <div>
              <label htmlFor="nombre" className="mb-2 block text-sm font-semibold text-slate-100">
                Nombre completo
              </label>
              <input
                id="nombre"
                name="nombre"
                type="text"
                value={formulario.nombre}
                onChange={manejarCambio}
                placeholder="Escribe tu nombre"
                aria-invalid={Boolean(errores.nombre)}
                aria-describedby={errores.nombre ? 'error-nombre' : undefined}
                className={`w-full rounded-xl border bg-slate-950/60 px-4 py-3 text-white outline-none transition placeholder:text-slate-500 focus:ring-2 ${
                  errores.nombre ? 'border-rose-400 focus:ring-rose-400/30' : 'border-slate-700 focus:border-indigo-400 focus:ring-indigo-400/30'
                }`}
              />
              {errores.nombre && <p id="error-nombre" className="mt-2 text-sm text-rose-300">{errores.nombre}</p>}
            </div>

            <div>
              <label htmlFor="email" className="mb-2 block text-sm font-semibold text-slate-100">
                Correo electrónico
              </label>
              <input
                id="email"
                name="email"
                type="email"
                value={formulario.email}
                onChange={manejarCambio}
                placeholder="nombre@correo.com"
                aria-invalid={Boolean(errores.email)}
                aria-describedby={errores.email ? 'error-email' : undefined}
                className={`w-full rounded-xl border bg-slate-950/60 px-4 py-3 text-white outline-none transition placeholder:text-slate-500 focus:ring-2 ${
                  errores.email ? 'border-rose-400 focus:ring-rose-400/30' : 'border-slate-700 focus:border-indigo-400 focus:ring-indigo-400/30'
                }`}
              />
              {errores.email && <p id="error-email" className="mt-2 text-sm text-rose-300">{errores.email}</p>}
            </div>

            <div>
              <label htmlFor="mensaje" className="mb-2 block text-sm font-semibold text-slate-100">
                Mensaje
              </label>
              <textarea
                id="mensaje"
                name="mensaje"
                rows="5"
                value={formulario.mensaje}
                onChange={manejarCambio}
                placeholder="Cuéntanos en qué podemos ayudarte..."
                aria-invalid={Boolean(errores.mensaje)}
                aria-describedby={errores.mensaje ? 'error-mensaje' : undefined}
                className={`w-full resize-y rounded-xl border bg-slate-950/60 px-4 py-3 text-white outline-none transition placeholder:text-slate-500 focus:ring-2 ${
                  errores.mensaje ? 'border-rose-400 focus:ring-rose-400/30' : 'border-slate-700 focus:border-indigo-400 focus:ring-indigo-400/30'
                }`}
              />
              {errores.mensaje && <p id="error-mensaje" className="mt-2 text-sm text-rose-300">{errores.mensaje}</p>}
            </div>

            <button
              type="submit"
              className="w-full rounded-xl bg-indigo-500 px-5 py-3.5 font-bold text-white shadow-lg shadow-indigo-500/25 transition hover:bg-indigo-400 focus:outline-none focus:ring-4 focus:ring-indigo-400/30 active:scale-[0.99]"
            >
              Enviar mensaje
            </button>
            <p className="text-center text-xs text-slate-400">
              Todos los campos son obligatorios. El envío de esta actividad es una simulación.
            </p>
          </form>
        </section>

        <footer className="mt-8 text-center text-sm text-slate-500">
          Formulario de Contacto · React + Tailwind CSS
        </footer>
      </div>
    </main>
  )
}

export default App